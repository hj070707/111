package client;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class StudentClientDialog extends JFrame implements ActionListener{
	private JTextField jtfIP;
	private JButton jbtConnect;
	private JButton jbtClose;
	private JTextField jtfStudentNo;
	private JButton jbtQuery;
	private JTable jTable;
	private DefaultTableModel tableModel;
	private Socket socket;
	private boolean connected = false;

	public StudentClientDialog(){
		super("成绩查询");
		this.setSize(500, 400);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
		topPanel.add(new JLabel("IP地址："));
		jtfIP = new JTextField("127.0.0.1", 12);
		topPanel.add(jtfIP);
		jbtConnect = new JButton("连接");
		jbtClose = new JButton("关闭");
		jbtClose.setEnabled(false);
		topPanel.add(jbtConnect);
		topPanel.add(jbtClose);
		getContentPane().add(topPanel, BorderLayout.NORTH);

		JPanel queryPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
		queryPanel.add(new JLabel("学号："));
		jtfStudentNo = new JTextField(15);
		jbtQuery = new JButton("查询");
		jbtQuery.setEnabled(false);
		queryPanel.add(jtfStudentNo);
		queryPanel.add(jbtQuery);
		getContentPane().add(queryPanel, BorderLayout.CENTER);

		String[] columns = {"课程号","课程名","成绩"};
		tableModel = new DefaultTableModel(columns,0){
			@Override
			public boolean isCellEditable(int row, int column){
				return false;
			}
		};
		jTable = new JTable(tableModel);
		JScrollPane jScrollPane = new JScrollPane(jTable);

		JPanel centerPanel = new JPanel(new BorderLayout());
		centerPanel.add(queryPanel, BorderLayout.NORTH);
		centerPanel.add(jScrollPane, BorderLayout.CENTER);
		getContentPane().add(centerPanel, BorderLayout.CENTER);

		jbtConnect.addActionListener(this);
		jbtClose.addActionListener(this);
		jbtQuery.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtConnect){
			String ip = jtfIP.getText().trim();
			if(ip.isEmpty()){
				JOptionPane.showMessageDialog(this, "请输入服务器IP地址！");
				return;
			}
			try{
				socket = new Socket(ip, 8888);
				connected = true;
				jbtConnect.setEnabled(false);
				jbtClose.setEnabled(true);
				jbtQuery.setEnabled(true);
				jtfIP.setEditable(false);
				JOptionPane.showMessageDialog(this, "连接成功！");
			}catch(IOException ex){
				JOptionPane.showMessageDialog(this, "连接失败：" + ex.getMessage());
			}
		}else if(e.getSource()==jbtClose){
			try{
				if(socket != null && !socket.isClosed()){
					socket.close();
				}
			}catch(IOException ex){
				ex.printStackTrace();
			}
			connected = false;
			jbtConnect.setEnabled(true);
			jbtClose.setEnabled(false);
			jbtQuery.setEnabled(false);
			jtfIP.setEditable(true);
			tableModel.setRowCount(0);
		}else if(e.getSource()==jbtQuery){
			String studentNo = jtfStudentNo.getText().trim();
			if(studentNo.isEmpty()){
				JOptionPane.showMessageDialog(this, "请输入学号！");
				return;
			}
			if(!connected || socket == null || socket.isClosed()){
				JOptionPane.showMessageDialog(this, "请先连接服务器！");
				return;
			}
			try{
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

				out.println(studentNo);
				String response = in.readLine();

				tableModel.setRowCount(0);
				if("NOT_FOUND".equals(response)){
					JOptionPane.showMessageDialog(this, "未找到该学生的成绩信息！");
				}else{
					String[] courses = response.split(";");
					for(String course : courses){
						if(!course.isEmpty()){
							String[] parts = course.split(",");
							if(parts.length == 3){
								tableModel.addRow(new Object[]{parts[0], parts[1], parts[2]});
							}
						}
					}
				}
			}catch(IOException ex){
				JOptionPane.showMessageDialog(this, "查询失败：" + ex.getMessage());
			}
		}
	}

	public static void main(String[] args){
		new StudentClientDialog().setVisible(true);
	}
}
