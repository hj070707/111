package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collection;

import course.Course;
import main.SGS;
import score.Score;
import user.Student;

public class ScoreServer implements Runnable{
	private ServerSocket serverSocket;
	private boolean running = false;
	private int port = 8888;

	public void startServer(){
		if(running){
			return;
		}
		try{
			serverSocket = new ServerSocket(port);
			running = true;
			Thread thread = new Thread(this);
			thread.start();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	public void stopServer(){
		running = false;
		try{
			if(serverSocket != null && !serverSocket.isClosed()){
				serverSocket.close();
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	public boolean isRunning(){
		return running;
	}

	public void run(){
		while(running){
			try{
				Socket socket = serverSocket.accept();
				new Thread(new ClientHandler(socket)).start();
			}catch(IOException e){
				if(!running){
					break;
				}
				e.printStackTrace();
			}
		}
	}

	private class ClientHandler implements Runnable{
		private Socket socket;

		public ClientHandler(Socket socket){
			this.socket = socket;
		}

		public void run(){
			try{
				BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

				String studentNo = in.readLine();

				StringBuilder result = new StringBuilder();
				Collection<Course> courses = SGS.courseCatalog.getAllCourses().values();
				boolean found = false;
				for(Course c : courses){
					Score score = c.findScore(studentNo);
					if(score != null){
						result.append(c.getCourseNo()).append(",")
							.append(c.getCourseName()).append(",")
							.append(score.getGrade()).append(";");
						found = true;
					}
				}
				if(found){
					out.println(result.toString());
				}else{
					out.println("NOT_FOUND");
				}

				in.close();
				out.close();
				socket.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}
	}
}
