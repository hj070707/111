package course;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import main.SGS;
import user.Teacher;

/**
*
* @ClassName: CourseEditDialog
* @Description: 课程信息编辑对话框类：用于添加和修改课程信息
* @author zhoushaobin
* @date 2017年7月7日
*
*/
public class CourseEditDialog extends JDialog implements ActionListener{
	private JTextField jtfCourseNo;
	private JTextField jtfCourseName;
	private JTextField jtfCredit;
	private JTextField jtfSemster;
	private JTextField jtfPeriod;
	private JComboBox<String> jcbTeacher;
	private JButton jbtSave;
	private JButton jbtCancel;
	private Course course;
	private boolean saved = false;
	private DefaultComboBoxModel<String> teacherModel;

	public CourseEditDialog(Dialog parent, Course course){
		super(parent, course == null ? "添加课程" : "修改课程信息", true);
		this.course = course;

		this.setSize(300, 280);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
		jtfCourseNo = new JTextField(15);
		jtfCourseName = new JTextField(15);
		jtfCredit = new JTextField(15);
		jtfSemster = new JTextField(15);
		jtfPeriod = new JTextField(15);
		teacherModel = new DefaultComboBoxModel<String>();
		jcbTeacher = new JComboBox<String>(teacherModel);

		loadTeachers();

		formPanel.add(new JLabel("课程编号："));
		formPanel.add(jtfCourseNo);
		formPanel.add(new JLabel("课程名称："));
		formPanel.add(jtfCourseName);
		formPanel.add(new JLabel("课程学分："));
		formPanel.add(jtfCredit);
		formPanel.add(new JLabel("开课学年："));
		formPanel.add(jtfSemster);
		formPanel.add(new JLabel("开课学期："));
		formPanel.add(jtfPeriod);
		formPanel.add(new JLabel("教师："));
		formPanel.add(jcbTeacher);

		if(course != null){
			jtfCourseNo.setText(course.getCourseNo());
			jtfCourseNo.setEditable(false);
			jtfCourseName.setText(course.getCourseName());
			jtfCredit.setText(String.valueOf(course.getCredit()));
			jtfSemster.setText(String.valueOf(course.getSemster()));
			jtfPeriod.setText(String.valueOf(course.getPeriod()));
			Teacher t = course.getTeacher();
			String teacherStr = t.getUserNo() + ":" + t.getName();
			jcbTeacher.setSelectedItem(teacherStr);
		}

		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
		jbtSave = new JButton("保存");
		jbtCancel = new JButton("取消");
		buttonPanel.add(jbtSave);
		buttonPanel.add(jbtCancel);

		getContentPane().add(formPanel, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);

		jbtSave.addActionListener(this);
		jbtCancel.addActionListener(this);
	}

	private void loadTeachers(){
		teacherModel.removeAllElements();
		Collection<Teacher> teachers = SGS.faculty.values();
		for(Teacher t : teachers){
			teacherModel.addElement(t.getUserNo() + ":" + t.getName());
		}
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtSave){
			String courseNo = jtfCourseNo.getText().trim();
			String courseName = jtfCourseName.getText().trim();
			String creditStr = jtfCredit.getText().trim();
			String semsterStr = jtfSemster.getText().trim();
			String periodStr = jtfPeriod.getText().trim();
			String teacherItem = (String)jcbTeacher.getSelectedItem();

			if(courseNo.isEmpty()){
				JOptionPane.showMessageDialog(this, "课程编号不能为空！");
				return;
			}
			if(courseName.isEmpty()){
				JOptionPane.showMessageDialog(this, "课程名称不能为空！");
				return;
			}
			int credit;
			try{
				credit = Integer.parseInt(creditStr);
			}catch(NumberFormatException ex){
				JOptionPane.showMessageDialog(this, "课程学分为有效数字！");
				return;
			}
			int semster;
			try{
				semster = Integer.parseInt(semsterStr);
			}catch(NumberFormatException ex){
				JOptionPane.showMessageDialog(this, "开课学年为有效数字！");
				return;
			}
			int period;
			try{
				period = Integer.parseInt(periodStr);
			}catch(NumberFormatException ex){
				JOptionPane.showMessageDialog(this, "开课学期为有效数字！");
				return;
			}
			if(teacherItem == null || teacherItem.isEmpty()){
				JOptionPane.showMessageDialog(this, "请选择授课教师！");
				return;
			}

			String teacherNo = teacherItem.split(":")[0];
			Teacher teacher = SGS.faculty.get(teacherNo);
			if(teacher == null){
				JOptionPane.showMessageDialog(this, "教师信息不存在！");
				return;
			}

			if(course == null){
				if(SGS.courseCatalog.containsCourse(courseNo)){
					JOptionPane.showMessageDialog(this, "课程编号已存在！");
					return;
				}
				Course newCourse = new Course(courseNo, courseName, credit, semster, period, teacher);
				SGS.courseCatalog.addCourse(newCourse);
				JOptionPane.showMessageDialog(this, "添加成功！");
			}else{
				Course updatedCourse = new Course(courseNo, courseName, credit, semster, period, teacher);
				updatedCourse.getStudentList().addAll(course.getStudentList());
				updatedCourse.getScoreBook().putAll(course.getScoreBook());
				SGS.courseCatalog.updateCourse(updatedCourse);
				JOptionPane.showMessageDialog(this, "修改成功！");
			}
			saved = true;
			this.dispose();
		}else if(e.getSource()==jbtCancel){
			this.dispose();
		}
	}

	public boolean isSaved(){
		return saved;
	}
}
