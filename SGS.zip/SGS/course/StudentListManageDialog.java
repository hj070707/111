package course;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import main.SGS;
import user.Student;

/**
*
* @ClassName: StudentListManageDialog
* @Description: 学生名单管理对话框类：显示课程学生名单，分配和移除学生
* @author zhoushaobin
* @date 2017年7月7日
*
*/
public class StudentListManageDialog extends JDialog implements ActionListener{
	private JComboBox<String> jcbCourse;
	private DefaultComboBoxModel<String> courseModel;
	private JButton jbtView;
	private JTable jTable;
	private DefaultTableModel tableModel;
	private JButton jbtAssign;
	private JButton jbtRemove;
	private Course currentCourse;
	private ArrayList<Student> currentStudents;

	public StudentListManageDialog(JFrame owner){
		super(owner,"学生名单");
		this.setSize(500, 380);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setModal(true);

		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
		courseModel = new DefaultComboBoxModel<String>();
		jcbCourse = new JComboBox<String>(courseModel);
		jbtView = new JButton("查看名单");
		topPanel.add(new JLabel("课程："));
		topPanel.add(jcbCourse);
		topPanel.add(jbtView);
		getContentPane().add(topPanel, BorderLayout.NORTH);

		String[] columns = {"学号","姓名","性别","年龄","系部"};
		tableModel = new DefaultTableModel(columns,0){
			@Override
			public boolean isCellEditable(int row, int column){
				return false;
			}
		};
		jTable = new JTable(tableModel);
		jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jScrollPane = new JScrollPane(jTable);
		getContentPane().add(jScrollPane, BorderLayout.CENTER);

		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 10));
		jbtAssign = new JButton("分配学生");
		jbtRemove = new JButton("移除学生");
		bottomPanel.add(jbtAssign);
		bottomPanel.add(jbtRemove);
		getContentPane().add(bottomPanel, BorderLayout.SOUTH);

		jbtView.addActionListener(this);
		jbtAssign.addActionListener(this);
		jbtRemove.addActionListener(this);

		loadCourses();
	}

	private void loadCourses(){
		courseModel.removeAllElements();
		Collection<Course> courses = SGS.courseCatalog.getAllCourses().values();
		for(Course c : courses){
			courseModel.addElement(c.getCourseNo() + c.getCourseName());
		}
	}

	private void refreshStudentList(){
		tableModel.setRowCount(0);
		if(currentCourse == null){
			return;
		}
		currentStudents = currentCourse.getStudentList();
		for(Student s : currentStudents){
			tableModel.addRow(new Object[]{
				s.getUserNo(),
				s.getName(),
				s.getSex(),
				s.getAge(),
				s.getDepartment()
			});
		}
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtView){
			String selectedItem = (String)jcbCourse.getSelectedItem();
			if(selectedItem == null || selectedItem.isEmpty()){
				JOptionPane.showMessageDialog(this, "请先选择课程！");
				return;
			}
			String courseNo = selectedItem.substring(0, 4);
			currentCourse = SGS.courseCatalog.findCourse(courseNo);
			if(currentCourse == null){
				JOptionPane.showMessageDialog(this, "未找到该课程！");
				return;
			}
			refreshStudentList();
		}else if(e.getSource()==jbtAssign){
			if(currentCourse == null){
				JOptionPane.showMessageDialog(this, "请先选择课程并查看名单！");
				return;
			}
			StudentSelectDialog selectDialog = new StudentSelectDialog(this, currentCourse);
			selectDialog.setVisible(true);
			Student selectedStudent = selectDialog.getSelectedStudent();
			if(selectedStudent != null){
				currentCourse.addStudent(selectedStudent);
				refreshStudentList();
				JOptionPane.showMessageDialog(this, "分配成功！");
			}
		}else if(e.getSource()==jbtRemove){
			if(currentCourse == null){
				JOptionPane.showMessageDialog(this, "请先选择课程并查看名单！");
				return;
			}
			int selectedRow = jTable.getSelectedRow();
			if(selectedRow < 0){
				JOptionPane.showMessageDialog(this, "请先选择要移除的学生！");
				return;
			}
			String studentNo = (String)tableModel.getValueAt(selectedRow, 0);
			String studentName = (String)tableModel.getValueAt(selectedRow, 1);
			int result = JOptionPane.showConfirmDialog(this,
				"确认要移除该学生？\n" + studentNo + " " + studentName,
				"移除", JOptionPane.OK_CANCEL_OPTION);
			if(result == JOptionPane.OK_OPTION){
				Student student = SGS.school.get(studentNo);
				if(student != null){
					currentCourse.removeStudent(student);
					refreshStudentList();
				}
			}
		}
	}
}
