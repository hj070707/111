package course;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import main.SGS;
import user.Teacher;

/**
*
* @ClassName: CourseManageDialog
* @Description: 课程管理对话框类：显示课程列表，提供添加、修改、删除功能
* @author zhoushaobin
* @date 2017年7月7日
*
*/
public class CourseManageDialog extends JDialog implements ActionListener{
	private JTable jTable;
	private DefaultTableModel tableModel;
	private JButton jbtAdd;
	private JButton jbtEdit;
	private JButton jbtDelete;
	private JButton jbtExit;

	public CourseManageDialog(JFrame owner){
		super(owner,"课程管理");
		this.setSize(500, 350);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setModal(true);

		String[] columns = {"课程号","课程名","学分","学年","学期","教师"};
		tableModel = new DefaultTableModel(columns,0){
			@Override
			public boolean isCellEditable(int row, int column){
				return false;
			}
		};
		jTable = new JTable(tableModel);
		jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jScrollPane = new JScrollPane(jTable);
		getContentPane().add(jScrollPane, BorderLayout.CENTER);

		JPanel jPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
		jbtAdd = new JButton("添加课程");
		jbtEdit = new JButton("修改课程");
		jbtDelete = new JButton("删除课程");
		jbtExit = new JButton("退出");
		jPanel.add(jbtAdd);
		jPanel.add(jbtEdit);
		jPanel.add(jbtDelete);
		jPanel.add(jbtExit);
		getContentPane().add(jPanel, BorderLayout.SOUTH);

		jbtAdd.addActionListener(this);
		jbtEdit.addActionListener(this);
		jbtDelete.addActionListener(this);
		jbtExit.addActionListener(this);

		refreshTable();
	}

	private void refreshTable(){
		tableModel.setRowCount(0);
		Collection<Course> courses = SGS.courseCatalog.getAllCourses().values();
		for(Course c : courses){
			Teacher t = c.getTeacher();
			String teacherStr = t.getUserNo() + ":" + t.getName();
			tableModel.addRow(new Object[]{
				c.getCourseNo(),
				c.getCourseName(),
				c.getCredit(),
				c.getSemster(),
				c.getPeriod(),
				teacherStr
			});
		}
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtAdd){
			CourseEditDialog editDialog = new CourseEditDialog(this, null);
			editDialog.setVisible(true);
			if(editDialog.isSaved()){
				refreshTable();
			}
		}else if(e.getSource()==jbtEdit){
			int selectedRow = jTable.getSelectedRow();
			if(selectedRow < 0){
				JOptionPane.showMessageDialog(this, "请先选择要修改的课程！");
				return;
			}
			String courseNo = (String)tableModel.getValueAt(selectedRow, 0);
			Course course = SGS.courseCatalog.findCourse(courseNo);
			if(course == null){
				JOptionPane.showMessageDialog(this, "未找到该课程信息！");
				return;
			}
			CourseEditDialog editDialog = new CourseEditDialog(this, course);
			editDialog.setVisible(true);
			if(editDialog.isSaved()){
				refreshTable();
			}
		}else if(e.getSource()==jbtDelete){
			int selectedRow = jTable.getSelectedRow();
			if(selectedRow < 0){
				JOptionPane.showMessageDialog(this, "请先选择要删除的课程！");
				return;
			}
			String courseNo = (String)tableModel.getValueAt(selectedRow, 0);
			String courseName = (String)tableModel.getValueAt(selectedRow, 1);
			int result = JOptionPane.showConfirmDialog(this,
				"确认要删除该课程信息？\n" + courseNo + " " + courseName,
				"删除", JOptionPane.OK_CANCEL_OPTION);
			if(result == JOptionPane.OK_OPTION){
				SGS.courseCatalog.removeCourse(courseNo);
				refreshTable();
			}
		}else if(e.getSource()==jbtExit){
			this.dispose();
		}
	}
}
