package course;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import main.SGS;
import user.Student;

/**
*
* @ClassName: StudentSelectDialog
* @Description: 学生选择对话框类：用于选择要分配的学生
* @author zhoushaobin
* @date 2017年7月7日
*
*/
public class StudentSelectDialog extends JDialog implements ActionListener{
	private JTable jTable;
	private DefaultTableModel tableModel;
	private JButton jbtSelect;
	private JButton jbtCancel;
	private ArrayList<Student> allStudents;
	private Student selectedStudent;
	private Course currentCourse;

	public StudentSelectDialog(Dialog parent, Course course){
		super(parent, "学生名单", true);
		this.currentCourse = course;

		this.setSize(400, 300);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		String[] columns = {"学号","姓名","性别","年龄","系部"};
		tableModel = new DefaultTableModel(columns,0){
			@Override
			public boolean isCellEditable(int row, int column){
				return false;
			}
		};
		jTable = new JTable(tableModel);
		jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jScrollPane = new JScrollPane(jTable);
		getContentPane().add(jScrollPane, BorderLayout.CENTER);

		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 10));
		jbtSelect = new JButton("选择");
		jbtCancel = new JButton("取消");
		buttonPanel.add(jbtSelect);
		buttonPanel.add(jbtCancel);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);

		jbtSelect.addActionListener(this);
		jbtCancel.addActionListener(this);

		loadStudents();
	}

	private void loadStudents(){
		tableModel.setRowCount(0);
		allStudents = new ArrayList<Student>();
		Collection<Student> students = SGS.school.values();
		for(Student s : students){
			if(!currentCourse.containsStudent(s)){
				allStudents.add(s);
				tableModel.addRow(new Object[]{
					s.getUserNo(),
					s.getName(),
					s.getSex(),
					s.getAge(),
					s.getDepartment()
				});
			}
		}
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtSelect){
			int selectedRow = jTable.getSelectedRow();
			if(selectedRow < 0){
				JOptionPane.showMessageDialog(this, "请先选择要分配的学生！");
				return;
			}
			selectedStudent = allStudents.get(selectedRow);
			this.dispose();
		}else if(e.getSource()==jbtCancel){
			selectedStudent = null;
			this.dispose();
		}
	}

	public Student getSelectedStudent(){
		return selectedStudent;
	}
}
