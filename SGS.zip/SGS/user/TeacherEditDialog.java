package user;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import main.SGS;

/**
*
* @ClassName: TeacherEditDialog
* @Description: 教师信息编辑对话框类：用于添加和修改教师信息
* @author zhoushaobin
* @date 2017年7月7日
*
*/
public class TeacherEditDialog extends JDialog implements ActionListener{
	private JTextField jtfUserNo;
	private JTextField jtfName;
	private JButton jbtSave;
	private JButton jbtCancel;
	private Teacher teacher;  //要修改的教师对象，null表示添加
	private boolean saved = false;

	/**
	 * 构造方法
	 * @param parent 父窗口
	 * @param teacher 要修改的教师对象，null表示新增
	 */
	public TeacherEditDialog(java.awt.Dialog parent, Teacher teacher){
		super(parent, teacher == null ? "添加教师" : "修改教师信息", true);
		this.teacher = teacher;

		this.setSize(300, 200);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		//构造表单面板
		JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 10));
		jtfUserNo = new JTextField(15);
		jtfName = new JTextField(15);
		formPanel.add(new JLabel("教师编号："));
		formPanel.add(jtfUserNo);
		formPanel.add(new JLabel("教师姓名："));
		formPanel.add(jtfName);

		//如果是修改模式，填充数据并禁用编号输入
		if(teacher != null){
			jtfUserNo.setText(teacher.getUserNo());
			jtfUserNo.setEditable(false);
			jtfName.setText(teacher.getName());
		}

		//构造按钮面板
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
		jbtSave = new JButton("保存");
		jbtCancel = new JButton("取消");
		buttonPanel.add(jbtSave);
		buttonPanel.add(jbtCancel);

		getContentPane().add(formPanel, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);

		//注册监听器
		jbtSave.addActionListener(this);
		jbtCancel.addActionListener(this);
	}

	/**
	 * 监听器的事件处理方法
	 */
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtSave){
			//保存
			String userNo = jtfUserNo.getText().trim();
			String name = jtfName.getText().trim();

			//数据校验
			if(userNo.isEmpty()){
				JOptionPane.showMessageDialog(this, "教师编号不能为空！");
				return;
			}
			if(name.isEmpty()){
				JOptionPane.showMessageDialog(this, "教师姓名不能为空！");
				return;
			}

			if(teacher == null){
				//添加模式：检查编号是否已存在
				if(SGS.faculty.containsKey(userNo)){
					JOptionPane.showMessageDialog(this, "教师编号已存在！");
					return;
				}
				Teacher newTeacher = new Teacher(userNo, name);
				SGS.faculty.put(userNo, newTeacher);
				JOptionPane.showMessageDialog(this, "添加成功！");
			}else{
				//修改模式：更新姓名
				teacher.setName(name);
				JOptionPane.showMessageDialog(this, "修改成功！");
			}
			saved = true;
			this.dispose();
		}else if(e.getSource()==jbtCancel){
			//取消
			this.dispose();
		}
	}

	/**
	 * 判断是否保存成功
	 */
	public boolean isSaved(){
		return saved;
	}
}
