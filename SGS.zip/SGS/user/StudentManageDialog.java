package user;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import main.SGS;

public class StudentManageDialog extends JDialog implements ActionListener{
	private JTable jTable;
	private DefaultTableModel tableModel;
	private JButton jbtAdd;
	private JButton jbtEdit;
	private JButton jbtDelete;
	private JButton jbtExit;

	public StudentManageDialog(JFrame owner){
		super(owner,"学生管理");
		this.setSize(500, 350);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setModal(true);

		String[] columns = {"学号","姓名","性别","年龄","系部"};
		tableModel = new DefaultTableModel(columns,0){
			@Override
			public boolean isCellEditable(int row, int column){
				return false;
			}
		};
		jTable = new JTable(tableModel);
		jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jScrollPane = new JScrollPane(jTable);
		getContentPane().add(jScrollPane, BorderLayout.CENTER);

		JPanel jPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
		jbtAdd = new JButton("添加");
		jbtEdit = new JButton("修改");
		jbtDelete = new JButton("删除");
		jbtExit = new JButton("退出");
		jPanel.add(jbtAdd);
		jPanel.add(jbtEdit);
		jPanel.add(jbtDelete);
		jPanel.add(jbtExit);
		getContentPane().add(jPanel, BorderLayout.SOUTH);

		jbtAdd.addActionListener(this);
		jbtEdit.addActionListener(this);
		jbtDelete.addActionListener(this);
		jbtExit.addActionListener(this);

		refreshTable();
	}

	private void refreshTable(){
		tableModel.setRowCount(0);
		Collection<Student> students = SGS.school.values();
		for(Student s : students){
			tableModel.addRow(new Object[]{
				s.getUserNo(),
				s.getName(),
				s.getSex(),
				s.getAge(),
				s.getDepartment()
			});
		}
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtAdd){
			StudentEditDialog editDialog = new StudentEditDialog(this, null);
			editDialog.setVisible(true);
			if(editDialog.isSaved()){
				refreshTable();
			}
		}else if(e.getSource()==jbtEdit){
			int selectedRow = jTable.getSelectedRow();
			if(selectedRow < 0){
				JOptionPane.showMessageDialog(this, "请先选择要修改的学生！");
				return;
			}
			String userNo = (String)tableModel.getValueAt(selectedRow, 0);
			Student student = SGS.school.get(userNo);
			if(student == null){
				JOptionPane.showMessageDialog(this, "未找到该学生信息！");
				return;
			}
			StudentEditDialog editDialog = new StudentEditDialog(this, student);
			editDialog.setVisible(true);
			if(editDialog.isSaved()){
				refreshTable();
			}
		}else if(e.getSource()==jbtDelete){
			int selectedRow = jTable.getSelectedRow();
			if(selectedRow < 0){
				JOptionPane.showMessageDialog(this, "请先选择要删除的学生！");
				return;
			}
			String userNo = (String)tableModel.getValueAt(selectedRow, 0);
			String name = (String)tableModel.getValueAt(selectedRow, 1);
			int result = JOptionPane.showConfirmDialog(this,
				"确认要删除该学生信息？\n" + userNo + " " + name,
				"删除", JOptionPane.OK_CANCEL_OPTION);
			if(result == JOptionPane.OK_OPTION){
				SGS.school.remove(userNo);
				refreshTable();
			}
		}else if(e.getSource()==jbtExit){
			this.dispose();
		}
	}
}
