package user;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import main.SGS;

/**
*
* @ClassName: TeacherManageDialog
* @Description: 教师管理对话框类：显示教师列表，提供添加、修改、删除功能
* @author zhoushaobin
* @date 2017年7月7日
*
*/
public class TeacherManageDialog extends JDialog implements ActionListener{
	private JTable jTable;
	private DefaultTableModel tableModel;
	private JButton jbtAdd;
	private JButton jbtEdit;
	private JButton jbtDelete;
	private JButton jbtExit;

	//构造方法
	public TeacherManageDialog(JFrame owner){
		super(owner,"教师管理");
		this.setSize(450, 350);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setModal(true);

		//构造表格模型
		String[] columns = {"教师编号","教师姓名"};
		tableModel = new DefaultTableModel(columns,0){
			@Override
			public boolean isCellEditable(int row, int column){
				return false; //表格只读
			}
		};
		jTable = new JTable(tableModel);
		jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jScrollPane = new JScrollPane(jTable);
		getContentPane().add(jScrollPane, BorderLayout.CENTER);

		//构造按钮面板
		JPanel jPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
		jbtAdd = new JButton("添加");
		jbtEdit = new JButton("修改");
		jbtDelete = new JButton("删除");
		jbtExit = new JButton("退出");
		jPanel.add(jbtAdd);
		jPanel.add(jbtEdit);
		jPanel.add(jbtDelete);
		jPanel.add(jbtExit);
		getContentPane().add(jPanel, BorderLayout.SOUTH);

		//注册监听器
		jbtAdd.addActionListener(this);
		jbtEdit.addActionListener(this);
		jbtDelete.addActionListener(this);
		jbtExit.addActionListener(this);

		//加载教师数据
		refreshTable();
	}

	/**
	 * 刷新表格数据
	 */
	private void refreshTable(){
		tableModel.setRowCount(0);
		Collection<Teacher> teachers = SGS.faculty.values();
		for(Teacher t : teachers){
			tableModel.addRow(new Object[]{t.getUserNo(), t.getName()});
		}
	}

	/**
	 * 监听器的事件处理方法
	 */
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtAdd){
			//添加教师
			TeacherEditDialog editDialog = new TeacherEditDialog(this, null);
			editDialog.setVisible(true);
			if(editDialog.isSaved()){
				refreshTable();
			}
		}else if(e.getSource()==jbtEdit){
			//修改教师
			int selectedRow = jTable.getSelectedRow();
			if(selectedRow < 0){
				JOptionPane.showMessageDialog(this, "请先选择要修改的教师！");
				return;
			}
			String userNo = (String)tableModel.getValueAt(selectedRow, 0);
			Teacher teacher = SGS.faculty.get(userNo);
			if(teacher == null){
				JOptionPane.showMessageDialog(this, "未找到该教师信息！");
				return;
			}
			TeacherEditDialog editDialog = new TeacherEditDialog(this, teacher);
			editDialog.setVisible(true);
			if(editDialog.isSaved()){
				refreshTable();
			}
		}else if(e.getSource()==jbtDelete){
			//删除教师
			int selectedRow = jTable.getSelectedRow();
			if(selectedRow < 0){
				JOptionPane.showMessageDialog(this, "请先选择要删除的教师！");
				return;
			}
			String userNo = (String)tableModel.getValueAt(selectedRow, 0);
			String name = (String)tableModel.getValueAt(selectedRow, 1);
			int result = JOptionPane.showConfirmDialog(this,
				"确认要删除教师 " + name + " (" + userNo + ") 吗？",
				"确认删除", JOptionPane.YES_NO_OPTION);
			if(result == JOptionPane.YES_OPTION){
				SGS.faculty.remove(userNo);
				JOptionPane.showMessageDialog(this, "删除成功！");
				refreshTable();
			}
		}else if(e.getSource()==jbtExit){
			this.dispose();
		}
	}
}
