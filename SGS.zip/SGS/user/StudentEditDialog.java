package user;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import main.SGS;

public class StudentEditDialog extends JDialog implements ActionListener{
	private JTextField jtfUserNo;
	private JTextField jtfName;
	private JRadioButton jrbMale;
	private JRadioButton jrbFemale;
	private JTextField jtfAge;
	private JTextField jtfDepartment;
	private JButton jbtSave;
	private JButton jbtCancel;
	private boolean saved = false;
	private Student student;

	public StudentEditDialog(JDialog parent, Student student){
		super(parent, student == null ? "添加学生" : "修改学生信息", true);
		this.student = student;
		this.setSize(350, 350);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		JPanel mainPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));

		JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		panel1.add(new JLabel("学生编号："));
		jtfUserNo = new JTextField(15);
		panel1.add(jtfUserNo);
		mainPanel.add(panel1);

		JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		panel2.add(new JLabel("学生姓名："));
		jtfName = new JTextField(15);
		panel2.add(jtfName);
		mainPanel.add(panel2);

		JPanel panel3 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		panel3.add(new JLabel("学生性别："));
		jrbMale = new JRadioButton("男");
		jrbFemale = new JRadioButton("女");
		ButtonGroup bg = new ButtonGroup();
		bg.add(jrbMale);
		bg.add(jrbFemale);
		jrbMale.setSelected(true);
		panel3.add(jrbMale);
		panel3.add(jrbFemale);
		mainPanel.add(panel3);

		JPanel panel4 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		panel4.add(new JLabel("学生年龄："));
		jtfAge = new JTextField(15);
		panel4.add(jtfAge);
		mainPanel.add(panel4);

		JPanel panel5 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
		panel5.add(new JLabel("所属系部："));
		jtfDepartment = new JTextField(15);
		panel5.add(jtfDepartment);
		mainPanel.add(panel5);

		getContentPane().add(mainPanel, BorderLayout.CENTER);

		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 10));
		jbtSave = new JButton("保存");
		jbtCancel = new JButton("取消");
		buttonPanel.add(jbtSave);
		buttonPanel.add(jbtCancel);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);

		jbtSave.addActionListener(this);
		jbtCancel.addActionListener(this);

		if(student != null){
			jtfUserNo.setText(student.getUserNo());
			jtfUserNo.setEditable(false);
			jtfName.setText(student.getName());
			if("男".equals(student.getSex())){
				jrbMale.setSelected(true);
			}else{
				jrbFemale.setSelected(true);
			}
			jtfAge.setText(String.valueOf(student.getAge()));
			jtfDepartment.setText(student.getDepartment());
		}
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==jbtSave){
			String userNo = jtfUserNo.getText().trim();
			String name = jtfName.getText().trim();
			String sex = jrbMale.isSelected() ? "男" : "女";
			String ageStr = jtfAge.getText().trim();
			String department = jtfDepartment.getText().trim();

			if(userNo.isEmpty() || name.isEmpty() || ageStr.isEmpty() || department.isEmpty()){
				JOptionPane.showMessageDialog(this, "请填写完整信息！");
				return;
			}

			int age;
			try{
				age = Integer.parseInt(ageStr);
			}catch(NumberFormatException ex){
				JOptionPane.showMessageDialog(this, "年龄必须为数字！");
				return;
			}

			if(student == null){
				if(SGS.school.containsKey(userNo)){
					JOptionPane.showMessageDialog(this, "该学号已存在！");
					return;
				}
				SGS.school.put(userNo, new Student(userNo, name, sex, age, department));
			}else{
				student.setName(name);
				student.setSex(sex);
				student.setAge(age);
				student.setDepartment(department);
			}

			saved = true;
			this.dispose();
		}else if(e.getSource()==jbtCancel){
			saved = false;
			this.dispose();
		}
	}

	public boolean isSaved(){
		return saved;
	}
}
